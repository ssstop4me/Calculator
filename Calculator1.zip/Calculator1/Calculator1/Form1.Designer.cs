﻿namespace Calculator1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Button[] btnNumbers;
        private System.Windows.Forms.Button btnAdd, btnSubtract, btnMultiply, btnDivide, btnEqual, btnClear, btnSqrt, btnPower;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblDisplay = new System.Windows.Forms.Label();
            this.btnNumbers = new System.Windows.Forms.Button[10];
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSubtract = new System.Windows.Forms.Button();
            this.btnMultiply = new System.Windows.Forms.Button();
            this.btnDivide = new System.Windows.Forms.Button();
            this.btnEqual = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSqrt = new System.Windows.Forms.Button();
            this.btnPower = new System.Windows.Forms.Button();

            this.SuspendLayout();

            // Label (дисплей)
            this.lblDisplay.Text = "0";
            this.lblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblDisplay.Font = new System.Drawing.Font("Arial", 16F);
            this.lblDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDisplay.Location = new System.Drawing.Point(10, 10);
            this.lblDisplay.Size = new System.Drawing.Size(260, 40);

            // Числовые кнопки (0-9)
            for (int i = 10 - 1; i >= 0; i--)
            {
                this.btnNumbers[i] = new System.Windows.Forms.Button();
                this.btnNumbers[i].Text = i.ToString();
                this.btnNumbers[i].Size = new System.Drawing.Size(50, 50);
                this.btnNumbers[i].Click += new System.EventHandler(this.btnNumber_Click);
            }

            // Операции
            this.btnAdd.Text = "+";
            this.btnSubtract.Text = "-";
            this.btnMultiply.Text = "*";
            this.btnDivide.Text = "/";
            this.btnEqual.Text = "=";
            this.btnClear.Text = "C";
            this.btnSqrt.Text = "√";
            this.btnPower.Text = "^";

            this.btnAdd.Click += new System.EventHandler(this.btnOperation_Click);
            this.btnSubtract.Click += new System.EventHandler(this.btnOperation_Click);
            this.btnMultiply.Click += new System.EventHandler(this.btnOperation_Click);
            this.btnDivide.Click += new System.EventHandler(this.btnOperation_Click);
            this.btnEqual.Click += new System.EventHandler(this.btnEqual_Click);
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            this.btnSqrt.Click += new System.EventHandler(this.btnSqrt_Click);
            this.btnPower.Click += new System.EventHandler(this.btnPower_Click);

            // Расположение кнопок
            int x = 10, y = 60;
            for (int i = 1; i <= 9; i++)
            {
                btnNumbers[i].Location = new System.Drawing.Point(x, y);
                this.Controls.Add(btnNumbers[i]);
                x += 60;
                if (i % 3 == 0) { x = 10; y += 60; }
            }
            btnNumbers[0].Location = new System.Drawing.Point(70, y + 60);
            this.Controls.Add(btnNumbers[0]);

            // Расположение операторов
            this.btnAdd.Location = new System.Drawing.Point(190, 60);
            this.btnSubtract.Location = new System.Drawing.Point(190, 120);
            this.btnMultiply.Location = new System.Drawing.Point(190, 180);
            this.btnDivide.Location = new System.Drawing.Point(190, 240);
            this.btnEqual.Location = new System.Drawing.Point(130, 300);
            this.btnClear.Location = new System.Drawing.Point(10, 300);
            this.btnSqrt.Location = new System.Drawing.Point(70, 240);
            this.btnPower.Location = new System.Drawing.Point(130, 240);

            // Добавляем элементы на форму
            this.Controls.Add(this.lblDisplay);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnSubtract);
            this.Controls.Add(this.btnMultiply);
            this.Controls.Add(this.btnDivide);
            this.Controls.Add(this.btnEqual);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSqrt);
            this.Controls.Add(this.btnPower);

            // Настройки формы
            this.ClientSize = new System.Drawing.Size(280, 370);
            this.Name = "Form1";
            this.Text = "Калькулятор: Андрей Тактоев";
            this.ResumeLayout(false);
        }
    }
}
