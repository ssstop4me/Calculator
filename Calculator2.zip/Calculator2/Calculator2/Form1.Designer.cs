﻿namespace Calculator2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Button[] btnNumbers;
        private System.Windows.Forms.Button btnAdd, btnSubtract, btnMultiply, btnDivide, btnEqual, btnClear;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblDisplay = new System.Windows.Forms.Label();
            this.btnNumbers = new System.Windows.Forms.Button[10];
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSubtract = new System.Windows.Forms.Button();
            this.btnMultiply = new System.Windows.Forms.Button();
            this.btnDivide = new System.Windows.Forms.Button();
            this.btnEqual = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();

            this.SuspendLayout();

            // Label (дисплей)
            this.lblDisplay.Text = "0";
            this.lblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblDisplay.Font = new System.Drawing.Font("Arial", 18F);
            this.lblDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDisplay.Location = new System.Drawing.Point(10, 10);
            this.lblDisplay.Size = new System.Drawing.Size(260, 50);

            // Числовые кнопки (0-9) - Расположение сеткой
            int startX = 10, startY = 70;
            int buttonSize = 50;
            for (int i = 0; i < 10; i++)
            {
                this.btnNumbers[i] = new System.Windows.Forms.Button();
                this.btnNumbers[i].Text = i.ToString();
                this.btnNumbers[i].Size = new System.Drawing.Size(buttonSize, buttonSize);
                this.btnNumbers[i].Click += new System.EventHandler(this.btnNumber_Click);

                // Расположение кнопок
                int row = (i == 0) ? 3 : (2 - (i - 1) / 3); // 0 внизу, остальные выше
                int col = (i == 0) ? 1 : (i - 1) % 3;
                this.btnNumbers[i].Location = new System.Drawing.Point(startX + col * (buttonSize + 10), startY + row * (buttonSize + 10));

                this.Controls.Add(this.btnNumbers[i]);
            }

            // Кнопки операций
            int opX = 190, opY = 70;
            this.btnAdd.Location = new System.Drawing.Point(opX, opY);
            this.btnSubtract.Location = new System.Drawing.Point(opX, opY + 60);
            this.btnMultiply.Location = new System.Drawing.Point(opX, opY + 120);
            this.btnDivide.Location = new System.Drawing.Point(opX, opY + 180);
            this.btnEqual.Location = new System.Drawing.Point(70, opY + 240);
            this.btnClear.Location = new System.Drawing.Point(10, opY + 240);

            this.btnAdd.Text = "+";
            this.btnSubtract.Text = "-";
            this.btnMultiply.Text = "*";
            this.btnDivide.Text = "/";
            this.btnEqual.Text = "=";
            this.btnClear.Text = "C";

            this.btnAdd.Size = this.btnSubtract.Size = this.btnMultiply.Size = this.btnDivide.Size = new System.Drawing.Size(50, 50);
            this.btnEqual.Size = new System.Drawing.Size(120, 50);
            this.btnClear.Size = new System.Drawing.Size(50, 50);

            this.btnAdd.Click += new System.EventHandler(this.btnOperation_Click);
            this.btnSubtract.Click += new System.EventHandler(this.btnOperation_Click);
            this.btnMultiply.Click += new System.EventHandler(this.btnOperation_Click);
            this.btnDivide.Click += new System.EventHandler(this.btnOperation_Click);
            this.btnEqual.Click += new System.EventHandler(this.btnEqual_Click);
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            this.Controls.Add(this.lblDisplay);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnSubtract);
            this.Controls.Add(this.btnMultiply);
            this.Controls.Add(this.btnDivide);
            this.Controls.Add(this.btnEqual);
            this.Controls.Add(this.btnClear);

            this.ClientSize = new System.Drawing.Size(280, 350);
            this.Name = "Form1";
            this.Text = "Калькулятор: Андрей Тактоев";
            this.ResumeLayout(false);
        }
    }
}
