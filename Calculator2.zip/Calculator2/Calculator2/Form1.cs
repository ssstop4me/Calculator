using System;
using System.Windows.Forms;

namespace Calculator2
{
    public partial class Form1 : Form
    {
        double num1, num2, result;
        string operation;
        bool isNewNumber = true;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnNumber_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (isNewNumber) lblDisplay.Text = "";
            lblDisplay.Text += btn.Text;
            isNewNumber = false;
        }

        private void btnOperation_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            num1 = Convert.ToDouble(lblDisplay.Text);
            operation = btn.Text;
            isNewNumber = true;
        }

        private void btnEqual_Click(object sender, EventArgs e)
        {
            num2 = Convert.ToDouble(lblDisplay.Text);
            switch (operation)
            {
                case "+": result = num1 + num2; break;
                case "-": result = num1 - num2; break;
                case "*": result = num1 * num2; break;
                case "/": result = num2 != 0 ? num1 / num2 : double.NaN; break;
            }
            lblDisplay.Text = result.ToString();
            isNewNumber = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = "0";
            num1 = num2 = result = 0;
            operation = "";
            isNewNumber = true;
        }
    }
}
